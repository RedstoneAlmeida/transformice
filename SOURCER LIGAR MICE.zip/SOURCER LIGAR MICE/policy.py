import os
import logging
import time
import sys
from datetime import datetime

logging.basicConfig(filename='./logs/controller.log',level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

EXEVERS=False

def main():
    if sys.platform.startswith('win'):
        if EXEVERS:
            print "Iniciando GameServer..."
            status = os.system("PolicyRequest.exe")
        else:
            print "Iniciando GameServer..."
            status = os.system("PolicyRequest.py")
    else:
        print "Iniciando GameServer..."
        status = os.system("python ./PolicyRequest.py")
    logging.info("Server stopped with a status code of: "+str(status))
    #             Windows               Linux
    if str(status)=="5" or str(status)=="1280":
        print str(datetime.today())+" Servidor parado."
        os._exit(0)
    elif str(status)=="10" or str(status)=="2560":
        print str(datetime.today())+" Servidor reiniciado."
        status=""
        main()
    elif str(status)=="11" or str(status)=="2816":
        print str(datetime.today())+" Servidor reiniciado para limpar o log de ??erro."
        if sys.platform.startswith('win'):
            os.system("del ./logs/error.log")
        else:
            os.system("rm ./logs/error.log")
        status=""
        main()
    else:
        print str(datetime.today())+" Servidor caiu, reiniciando em 10 segundos."
        time.sleep(20)
        status=""
        main()

if __name__ == '__main__':
    main()
