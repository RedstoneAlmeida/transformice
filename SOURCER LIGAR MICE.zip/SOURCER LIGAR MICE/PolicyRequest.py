from socket import socket
from struct import pack
from datetime import datetime
from os import system
system('color A'); system('mode 45,7'); system('title Policy Delay')
#By Igoor & Someusername

def box1():
    system("cls")
    print '============================================'
    print '= Policy request sent, Waiting for reply.. ='
    print '=                                          ='
    print '============================================'
    print '=                                          ='
    print '============================================'

def box2(a):
    system("cls")
    print '============================================'
    print '= Policy request sent, Waiting for reply.. ='
    print '= Policy received [Delay: '+a+']  ='
    print '============================================'
    print '= Press any key to exit                    ='
    print '============================================'

def main(IP, PORT):
    ServerIP=IP
    ServerPort=PORT
    s = socket()
    try:
        s.connect((ServerIP, ServerPort))
        packet = pack('23B', 60, 112, 111, 108, 105, 99, 121, 45, 102, 105, 108, 101, 45, 114, 101, 113, 117, 101, 115, 116, 47, 62, 00)
        s.send(packet)
        policyfile = s.recv(512)
    except socket.error, msg:
        policyfile = ""
    if policyfile=="":
        policyfile="None"
    TimeUsed = datetime.now() - Start;
    box2(str(TimeUsed))
    s.close()
    system("pause >nul")

if __name__ == '__main__':
    while 1:
        Start = datetime.now()
        box1()
        main("25.174.159.238", 443)
