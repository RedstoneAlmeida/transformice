# -*- coding: cp1252 -*-
import time

class blRace:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.countStats = True
        room.isblRace = True
        room.noShaman = True
        room.never20secTimer = True
        room.roundTime = 120

    def event_newround(self, player):
        self.players[player.playerCode].ballons = 10

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(32)
        player.enableKey(9)
        player.sendMessage("<N>Bem-vindo a sala <ROSE>Ballon Race<N>! <n>\nVoc� poder� usar <J>10 <ROSE>Bal�es<N>!\nAperte <J>Espa�o<N> para ganhar <J>1 <ROSE>Bal�o<N> :)\nDuvidas? Aperte <J>TAB<N>!")

    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 32:
            if self.players[player.playerCode].ballons > 1: 
                x = int(player.x)/3
                y = int(player.y)/3-90
                player.spawnObject(28, int(x), int(y),int(0))
                player.room.sendAll("\x08\x10", [player.playerCode])
                self.players[player.playerCode].ballons -= 1
                player.sendMessage("<N>Voc� usou <J>1 <N>bal�o, agora voc� tem <J>"+str(self.players[player.playerCode].ballons)+" bal�es.")
            else:
                player.sendMessage("<N>Seus bal�es acabar�o :(")
        elif key == 9:
            player.sendMessage("<J>Nada")

class Sharpie:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        pass

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        pass
				
class Video:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.countStats = True
        room.isvideo = True
        room.noShaman = True
        room.never20secTimer = True
        room.roundTime = 0
		
    def event_newround(self, player):
        pass

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        pass		

class Control:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        if player.isShaman:
            player.sendMessage("<CH>Aperte as teclas indicadoras para controlar os ratos.")
            player.sendPlayerDied(player.playerCode, player.score)
            player.isDead = True
            player.enableKey(37)
            player.enableKey(38)
            player.enableKey(39)
            player.enableKey(40)

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if player.isShaman:
            if key == 37: #esquerda
                    player.room.sendAll("\x05"+"\x16", ["-10", "10"])
            elif key == 38: #cima
                    player.room.sendAll("\x05"+"\x16", ["0", "-10"])
            elif key == 39: #direita
                    player.room.sendAll("\x05"+"\x16", ["10", "10"])
            elif key == 40: #baixo
                    player.room.sendAll("\x05"+"\x16", ["0", "10"])

class teste:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        if player.isShaman:
            player.sendMessage("<CH>Aperte as teclas indicadoras para controlar os ratos.")
            player.sendPlayerDied(player.playerCode, player.score)
            player.isDead = True
            player.enableKey(37)
            player.enableKey(38)
            player.enableKey(39)
            player.enableKey(40)

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
		
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if player.isShaman:
            if key == 37: #esquerda
                    player.room.sendAll("\x05"+"\x16", ["-5", "5"])
            elif key == 38: #cima
                    player.room.sendAll("\x05"+"\x16", ["0", "-5"])
            elif key == 39: #direita
                    player.room.sendAll("\x05"+"\x16", ["5", "5"])
            elif key == 40: #baixo
                    player.room.sendAll("\x05"+"\x16", ["0", "5"])					
					
class TrainingBC:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.never20secTimer = True
        room.noLook = True
        room.noKillAfk = True
        room.isBootcamp = True

    def event_newround(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.btpoints = 20
        iplayer.sx = 10
        iplayer.sy = 10

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(32)
        player.sendMessage("<ROSE>Welcome to <J>training bootcamp<ROSE>!\nYou start with <J>20 <ROSE>points, each time you load a checkpoint you lose <J>1 <ROSE>point. Be careful with yout points!")
        player.sendMessage("<J>C <VP>to save yout position, <J>SPACEBAR<VP> to load it!")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        player.room.respawnMice()

    def event_getcheese(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.sy = 0
        iplayer.sx = 0
        player.room.respawnMice()
        
    def event_keypress(self, player, key):
        iplayer = self.players[player.playerCode]
        if key == 32: #spacebar
                if iplayer.btpoints > 1:
                        if (not iplayer.sx == 0) and (not iplayer.sy == 0): 
                                iplayer.btpoints = iplayer.btpoints-1
                                x = int(iplayer.sx)/3.3
                                y = int(iplayer.sy)/3.5
                                player.movePlayer(player.username, x, y, False, 0, 0, True)
                                player.sendMessage("<VP>Loaded position, you have <N>"+str(iplayer.btpoints)+" <VP>points left")
                        else:
                                player.sendMessage("<VP>Please set a checkpoint using C before loading position")
                else:
                        player.sendMessage("<VP>You used up all your points! :(")
        elif key == ord("C"):
                iplayer.sx = player.x
                iplayer.sy = player.y
                player.sendMessage("<J>Saved your position")

class Brasil:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        room.never20secTimer = True
        room.noLook = True
        room.noKillAfk = True
        room.isBootcamp = True

    def event_newround(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.btpoints = 20
        iplayer.sx = 10
        iplayer.sy = 10

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("C"))
        player.enableKey(32)
        player.sendMessage("<ROSE>Seja Bem-vindo a sala <J>Brasil")
        player.sendMessage("<J>Pressione <R>Space <VP> para liberar sua cor verde!")
        player.sendMessage("<J>Pressione <R>Space <VP> para liberar sua cor verde!")		
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        player.room.respawnMice()

    def event_getcheese(self, player):
        iplayer = self.players[player.playerCode]
        iplayer.sy = 0
        iplayer.sx = 0
        player.room.respawnMice()
        
    def event_keypress(self, player, key):
        iplayer = self.players[player.playerCode]
        if key == 32: #spacebar
                                                        if not iplayer.isnomever:
                                                                iplayer.isnomever = True
                                                                furnonome = "c16464"																
                                                                hexcolor = struct.pack('!i', int(furnonome, 16))
                                                                iplayer.room.sendAllBin("\x1d\x04", struct.pack("!i", int(self.playerCode))+hexcolor)
                                                                iplayer.sendData("\x06"+"\x14",["<VP>Seu Nome Est� Verde."])
                                                        else:																
                                                                if iplayer.isnomever:
                                                                        iplayer.isnomever = False																
                                                                        iplayer.sendData("\x06"+"\x14",["Desativado"])
        elif key == ord("C"):
                iplayer.sx = player.x
                iplayer.sy = player.y
                player.sendMessage("<J>Saved your position")
class Traitor:
    def __init__(self):
        self.mg = Minigames

        self.cats = [7, 17]

        self.players = {}

    def load(self):
        pass

    def event_mouseduck(self, player):
        pass

    def event_createroom(self, room):
        pass

    def event_newround(self, player):
        self.players[player.playerCode].mordido = False

    def event_enterroom(self, player):
        self.players[player.playerCode] = Player(player.username)
        player.enableKey(ord("I"))
        player.enableKey(ord("O"))
        player.enableKey(32)
        player.sendMessage("<J>Bem-vindo ao TRAIDOR. Aperte I para maiores informa��es.")
        
    def event_leaveroom(self, player):
        del self.players[player.playerCode]

    def event_die(self, player):
        pass

    def event_getcheese(self, player):
        pass
        
    def event_keypress(self, player, key):
        if key == 32: #spacebar
                for rplayer in player.room.clients.values():
                    if not rplayer.username == player.username and not rplayer.isDead and not player.isDead and not self.players[rplayer.playerCode].mordido:
                        if rplayer.x >= player.x-300 and rplayer.x < player.x+300:
                            if rplayer.y >= player.y-200 and rplayer.y < player.y+200:
                                player.sendMessage("Voc� mordeu <R>"+rplayer.username+"<BL> ele ir� morrer em 5 segundos!")
                                rplayer.KillPlayerDelay(5)
                                self.players[rplayer.playerCode].mordido = True
                                break
        elif key == ord("I"):
                player.sendMessage("<J>Alguns de voc�s s�o os traidores! Eles podem mord�-lo e ap�s alguns segundos, voc� morrer�!\nTente adivinhar quem s�o os traidores escrevendo !NOMEDOJOGADOR no chat. Se tr�s jogadores suspeitarem de algu�m, ser� mostrada uma notifica��o e ent�o o jogador poder� ser morto com a barra de espa�o. Se tiver sorte, matar� o traidor ;-)\n Pode-se refazer a suspeita com TAB.\n<BL>Criado por <R>Igoor<BL>, ideia de <VP>Moepl.")
        elif key == ord("O"):
                player.sendMessage("<J>Em desenvolvimento.")
                #lst = self.username+" "*int(21-len(self.username))+str(self.playerCode)+" "*int(11-len(str(self.playerCode)))  				

class Player:
    def __init__(self, name):
        self.name = name
        self.ballons = 10
        self.nextshot = 0
        self.sx = 10
        self.sy = 10
        self.btpoints = 10
        self.mordido = False

class Minigames:
    def initMinigame(self, name, room):
        f = False
        print(name)
        if name.startswith("blrace"):
            room.minigame = blRace()
            f = True
        elif name.startswith("sharpie"):
            room.minigame = Sharpie()
            f = True
        elif name.startswith("Video"):
            room.minigame = Video()
            f = True	
        elif name.startswith("Brasil"):
            room.minigame = Brasil()
            f = True			
        elif name.startswith("control"):
            room.minigame = Control()
            f = True
        elif name.startswith("teste"):
            room.minigame = teste()
            f = True			
        elif name.startswith("trainingbootcamp"):
            room.minigame = TrainingBC()
            f = True
        elif name.startswith("traitor"):
            room.minigame = Traitor()
            f = True
        return f
